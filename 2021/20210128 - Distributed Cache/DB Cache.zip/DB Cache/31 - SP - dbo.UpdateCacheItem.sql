USE [MY_CACHE]
GO
CREATE OR ALTER PROCEDURE [dbo].[UpdateCacheItem] 
	@ID_Cache int
	 ,@Value_Cache varchar(4000)

	 WITH NATIVE_COMPILATION, SCHEMABINDING
AS
        
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english');
	
	UPDATE dbo.CACHE
	SET 
		Value_Cache = @Value_Cache
	WHERE 
		ID_Cache = @ID_Cache 
END

GO
