USE [MY_CACHE]
GO

CREATE OR ALTER PROCEDURE [utils].[DB_UTIL_CHECK_SIZE_ALL_IN_MEMORY_TABLES]
AS

SELECT 
	 DatabaseName = DB_NAME()
    ,Memory_Allocated_Objects_In_MB = ISNULL(SUM(memory_allocated_for_indexes_kb + memory_allocated_for_table_kb) /1024, 0)    	
FROM 
	sys.dm_db_xtp_table_memory_stats