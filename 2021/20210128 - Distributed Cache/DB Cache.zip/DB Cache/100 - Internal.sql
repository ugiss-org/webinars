-- Vediamo Alcune DMV

/*
	sys.dm_db_xtp_transactions
	E' utile per monitorare le transazioni in corso. E' come se questa vista ci permettesse 
	di sbirciare nella tabella delle transazioni globali
*/
	SELECT * 
	FROM sys.dm_db_xtp_transactions 
	WHERE transaction_id > 0

/*
	sys.dm_db_xtp_index_stats 
	Ha una riga per ogni indice su ciascuna tabella ottimizzata per la memoria. 
	C'� anche una colonna chiamata rows_expired_removed  che indica quante righe sono state scollegate da quell'indice.  
	Una volta che una riga � stata scollegata da tutti gli indici su una tabella, quella riga pu� essere rimossa dal thread di Garbage Collection. 
	Il valore rows_expired_removed aumentare fino a quando i contatori rows_expired non saranno stati 
	incrementati per ogni indice su una tabella ottimizzata per la memoria.
*/
	SELECT 
		[name] AS 'index_name' , s.index_id , scans_started , rows_returned , rows_expired , rows_expired_removed
	FROM 
		sys.dm_db_xtp_index_stats s 
		INNER JOIN sys.indexes i ON s.[object_id] = i.[object_id] AND s.index_id = i.index_id
	WHERE 
		OBJECT_ID('CACHE') = s.[object_id]
		AND [name] IS NOT NULL


/*
	sys.dm_exec_procedure_stats e sys.dm_exec_query_stats  
	La vista sys.dm_exec_query_stats � uno degli strumenti pi� comunemente usati per raccogliere informazioni sulle prestazioni ma, 
	per impostazione predefinita, non raccoglie dati dall'esecuzione di moduli compilati in modo nativo. 
	Questo perch� l'atto di raccogliere queste informazioni interne pu� rallentare leggermente l'esecuzione, ed i moduli compilati in modo nativo 
	sono stati progettati per non utilizzare pi� cicli di CPU di quanto assolutamente necessario. 
	Se hai davvero bisogno di raccogliere queste informazioni e vuoi che siano disponibili tramite sys.dm_exec_query_stats, 
	puoi eseguire una delle due stored procedure:

	- sys.sp_xtp_control_query_exec_stats: abilita la raccolta di statistiche per query per tutte le stored procedure compilate in modo nativo per l'istanza.
    - sys.sp_xtp_control_proc_exec_stats:  abilita la raccolta di statistiche a livello di procedura, per tutte le stored procedure compilate in modo nativo.
*/

	--Per abilitare in monitoraggio delle statistiche
	exec [sys].[sp_xtp_control_proc_exec_stats] @new_collection_value = 1  
	declare @c bit  
	exec sp_xtp_control_proc_exec_stats @old_collection_value=@c output  
	select @c as 'collection status'  

	--ES Top CPU 
	SELECT TOP 10 
		[object_id]
		,[database_name] = DB_NAME(database_id)
		,[stored_procedure] = OBJECT_NAME(object_id, database_id) 
		,cached_time
		,last_execution_time
		,total_elapsed_time
		,avg_elapsed_time = total_elapsed_time/execution_count
		,calls_minute = ISNULL(execution_count/DATEDIFF(MINUTE, cached_time, GETDATE()), 1)
		,last_elapsed_time
		,execution_count
		,avg_worker_time = total_worker_time/execution_count 
		,total_worker_time = total_worker_time
		,avg_logical_reads = total_logical_reads/execution_count 
		,total_logical_reads  
	FROM 
		sys.dm_exec_procedure_stats  
	WHERE 
		[object_id] IN (SELECT object_id FROM sys.sql_modules WHERE uses_native_compilation = 1) --Filter In-Memory Procedures
	ORDER BY 
		[total_worker_time] 
		--,[total_logical_reads]
		--,[total_logical_writes]
		--,[avg_elapsed_time]
		--,[execution_count]
	DESC



/*
	sys.dm_db_xtp_table_memory_stats
	La vista sys.dm_db_xtp_table_memory_stats fornisce statistiche sull'utilizzo della memoria per ogni tabella con ottimizzazione 
	per la memoria nel database corrente. Ricorda che le viste a gestione dinamica contenenti 
	il prefisso "db" hanno un ambito di database, quindi � necessario interrogarle nel contesto 
	del database che si desidera analizzare.
*/

SELECT  
	object_id 
    ,OBJECT_SCHEMA_NAME(object_id) + '.' + OBJECT_NAME(object_id) [Table_Name] 
    ,memory_allocated_for_table_kb 
    ,memory_used_by_table_kb 
    ,memory_used_by_table_kb 
    ,memory_allocated_for_indexes_kb 
    ,memory_used_by_indexes_kb
FROM    
	sys.dm_db_xtp_table_memory_stats

