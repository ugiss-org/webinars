USE [MY_CACHE]
GO

--Controllo la posizione dei file
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SELECT
	f.NAME AS [File Name]
	,f.physical_name AS [Physical Name]
	,CAST((f.size / 128.0) AS DECIMAL(15, 2)) AS [Total Size in MB]
	,CAST(f.size / 128.0 - CAST(FILEPROPERTY(f.NAME, 'SpaceUsed') AS INT) / 128.0 AS DECIMAL(15, 2)) AS [Available Space In MB]
	,[file_id]
	,fg.NAME AS [Filegroup Name]
FROM sys.database_files AS f
LEFT OUTER JOIN sys.data_spaces AS fg ON f.data_space_id = fg.data_space_id
OPTION (RECOMPILE) 


--Creo il filegroup INMEMORY
ALTER DATABASE [MY_CACHE] ADD FILEGROUP INMEMORY  
    CONTAINS MEMORY_OPTIMIZED_DATA
GO

--Aggiungo i file
ALTER DATABASE [MY_CACHE] ADD FILE (name='MY_CACHE_inmemory', filename='C:\Program Files\Microsoft SQL Server\MSSQL15.SQL2019\MSSQL\DATA\MY_CACHE_inmemory')  
    TO FILEGROUP INMEMORY
GO
