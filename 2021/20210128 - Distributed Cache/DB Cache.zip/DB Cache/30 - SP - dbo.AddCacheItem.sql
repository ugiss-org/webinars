USE [MY_CACHE]
GO

CREATE OR ALTER PROCEDURE [dbo].[AddCacheItem] 
	@ID_Cache int 
	,@Value_Cache varchar(4000) NOT NULL
	,@ExpirationDate datetime2(2) NOT NULL

	WITH NATIVE_COMPILATION, SCHEMABINDING
AS

BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english');
	
	INSERT INTO dbo.CACHE 
		  (ID_Cache
		  ,Value_Cache
		  ,ExpirationDate)
	VALUES 
		  (@ID_Cache
		  ,@Value_Cache
		  ,@ExpirationDate)
END

GO
