USE [MY_CACHE]
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCacheItem] 
	@ID_Cache int
	WITH NATIVE_COMPILATION, SCHEMABINDING
AS

BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english');
	
	SELECT 
		 Value_Cache
		 ,ExpirationDate
     FROM 
		 dbo.CACHE
	 WHERE 
		 ID_Cache = @ID_Cache 
END

GO
